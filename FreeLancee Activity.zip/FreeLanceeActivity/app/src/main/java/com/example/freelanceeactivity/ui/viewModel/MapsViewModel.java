package com.example.freelanceeactivity.ui.viewModel;

import androidx.lifecycle.ViewModel;

public class MapsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}