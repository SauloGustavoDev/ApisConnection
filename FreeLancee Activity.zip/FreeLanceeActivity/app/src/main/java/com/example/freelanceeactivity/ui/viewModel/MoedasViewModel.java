package com.example.freelanceeactivity.ui.viewModel;

import androidx.lifecycle.ViewModel;

public class MoedasViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}