package com.example.freelanceeactivity.ui.viewModel;

import androidx.lifecycle.ViewModel;

public class FilmesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}