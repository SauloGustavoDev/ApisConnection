package com.example.freelanceeactivity.model;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiFilmes {

    //@GET("")
    //Call<Model> getData();
}
