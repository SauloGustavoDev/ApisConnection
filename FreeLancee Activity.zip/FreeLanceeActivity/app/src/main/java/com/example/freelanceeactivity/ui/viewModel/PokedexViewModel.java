package com.example.freelanceeactivity.ui.viewModel;

import androidx.lifecycle.ViewModel;

public class PokedexViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}